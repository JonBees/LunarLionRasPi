This is the CI_LAB test application.

CI_LAB is a simple command uplink application that accepts CCSDS
telecommand packets over a UDP/IP port. 
It provides a test interface to a CFS system in a lab environment.  
It does not provide a full CCSDS Telecommand stack implementation. 

To use this application, first copy this "ci_lab" directory to the location
where the rest of the CFS applications are. Example:
/home/cfs/CFS_Project/apps


